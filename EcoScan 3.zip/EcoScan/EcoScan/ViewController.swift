//
//  ViewController.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-18.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

