//
//  TreeTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

extension String {
    func toImage() -> UIImage? {
        if let data = Data(base64Encoded: self, options: .ignoreUnknownCharacters){
            return UIImage(data: data)
        }
        return nil
    }
}

class TreeTabBar: UITabBarController {
    
    @IBOutlet weak var treeImage: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        drawTree()

        // instead of this, you want to show your tree screen here
        view.backgroundColor = .white;
        
        // Do any additional setup after loading the view.
    }
    
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //let indexArray = [ index0, index1, index2,index3, index4, index5]
    let items = [ "computer", "aluminum", "plastic", "paper", "glass", "wood"]
    let points = [ 45,15,12,9,6,3]
    let leaves = [ 15,5,4,3,2,1]

    func drawTree() {
        // let userPoints = points -> where is this point value & where are you getting it from?
        let userPoints = 3; // this is just for testing purposes
        var imageName : String!
        imageName = "tree.27.jpg"
            
        switch userPoints{
        case 3:
            imageName = "tree.27.jpg"
        case 6:
            imageName = "tree.26.jpg"
        case 9:
            imageName = "tree.25.jpg"
        // continue this structure for all images
        default:
            break
        }
        
        treeImage.image = UIImage(named: imageName)
    }


}
