//
//  RewardTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class SearchTabBar: UITabBarController {
    var userPoints = 0;
    var recycledItem = "";
    let items = ["computer", "aluminum", "plastic", "paper", "glass", "wood"]
    let points = [ 45,15,12,9,6,3]
    let leaves = [ 15,5,4,3,2,1]
    @IBAction func cardboard(_ sender: UIButton) {
    }
    
    @IBAction func plastics(_ sender: UIButton) {
      performSegue(withIdentifier: "plasticSegue", sender: self)
    }
    
    @IBAction func plasticBag(_ sender: UIButton) {
    }
    
    @IBAction func plasticBottle(_ sender: UIButton) {
        recycledItem = "plastic"
        performSegue(withIdentifier: "plasticBottleSegue", sender: self)
    }
    
    @IBAction func plasticCap(_ sender: UIButton) {
    }
    
    @IBAction func plasticContainer(_ sender: UIButton) {
    }
    
    @IBAction func plasticCup(_ sender: UIButton) {
    }
    
    @IBAction func recycled(_ sender: UIButton) {
        for item in items {
            if recycledItem = items[item] {
                userPoints = userPoints + points[item]
    }
        }
    }
    
    @IBAction func plasticCutlery(_ sender: UIButton) {
    }
    
    @IBAction func plasticHanger(_ sender: UIButton) {
    }
    
    @IBAction func plasticPot(_ sender: UIButton) {
    }
    
    @IBAction func rollOnDeodorant(_ sender: UIButton) {
    }
    
    
    @IBAction func yogurtCup(_ sender: UIButton) {
        recycledItem = "plastic"
        performSegue(withIdentifier: "yogurtCupSegue", sender: self)
    }
    @IBAction func recycledYogurt(_ sender: UIButton) {
        for item in items {
            if recycledItem = items[item] {
                userPoints = userPoints + points[item]
            }
        }
    }
    
    @IBAction func glass(_ sender: UIButton) {
    }
    
    @IBAction func aluminum(_ sender: UIButton) {
        performSegue(withIdentifier: "aluminumSegue", sender: self)
    }
    
    @IBAction func aerosols(_ sender: UIButton) {
    }
    
    @IBAction func can(_ sender: UIButton) {
    }
    
    @IBAction func drawingPin(_ sender: UIButton) {
    }
    
    @IBAction func foil(_ sender: UIButton) {
    }
    
    @IBAction func jarLids(_ sender: UIButton) {
    }
    
    @IBAction func metallicCaps(_ sender: UIButton) {
    }
    
    @IBAction func metalTubes(_ sender: UIButton) {
    }
    
    @IBAction func paintCan(_ sender: UIButton) {
    }
    
    @IBAction func paintCloverdale(_ sender: UIButton) {
    }
    
    
    @IBAction func organic(_ sender: UIButton) {
    }
    
    
    @IBAction func paper(_ sender: UIButton) {
    }
    
    @IBAction func batteries(_ sender: UIButton) {
    }
    
    @IBAction func special(_ sender: UIButton) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // instead of this, you want to show your search screen here
        view.backgroundColor = .blue;
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
