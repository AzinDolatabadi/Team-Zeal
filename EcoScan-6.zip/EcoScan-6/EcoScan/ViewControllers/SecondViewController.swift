//
//  ScanTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationTabBar: UITabBarController, UISearchBarDelegate, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBAction func searchButton(_ sender: UIBarButtonItem) {
    let searchController = UISearchController(searchResultsController: nil)
    searchController.searchBar.delegate = self
    present(searchController, animated: true, completion: nil)
}

func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
    
    //Ignoring User
    UIApplication.shared.beginIgnoringInteractionEvents()
    
    //Activity Indicator
    let activityIndicator = UIActivityIndicatorView()
    activityIndicator.style = UIActivityIndicatorView.Style.gray
    activityIndicator.center = self.view.center
    activityIndicator.hidesWhenStopped = true
    activityIndicator.startAnimating()
    
    self.view.addSubview(activityIndicator)
    
    //Hide search bar
    searchBar.resignFirstResponder()
    dismiss(animated: true, completion: nil)
    
    //Create the search request
    let searchRequest = MKLocalSearch.Request()
    searchRequest.naturalLanguageQuery = searchBar.text
    
    let activeSearch = MKLocalSearch(request: searchRequest)
    
    activeSearch.start { (response, error) in
        
        activityIndicator.stopAnimating()
        UIApplication.shared.endIgnoringInteractionEvents()
        
        if response == nil
        {
            print("ERROR")
        }
        else
        {
            //Remove annotations
            let annotations = self.myMapView.annotations
            self.myMapView.removeAnnotations(annotations)
            
            //Getting data
            let latitude = response?.boundingRegion.center.latitude
            let longitude = response?.boundingRegion.center.longitude
            
            //Create annotation
            let annotation = MKPointAnnotation()
            annotation.title = searchBar.text
            annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
            self.myMapView.addAnnotation(annotation)
            
            //Zooming in on Annotation
            let coordinate: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
            let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
            let region = MKCoordinateRegion(center: coordinate, span: span)
            self.myMapView.setRegion(region, animated: true)
        }
    }
}

    
    @IBOutlet weak var myMapView: MKMapView!

        var locationManager = CLLocationManager()
        let regionInMeters: Double = 10000
        
        override func viewDidLoad() {
            super.viewDidLoad()
            checkLocationServices()
            //       myMapView.delegate = self as? MKMapViewDelegate
            
            self.locationManager = CLLocationManager()
            self.locationManager.delegate = self
            //self.mapView.delegate = self
            self.locationManager.requestWhenInUseAuthorization()
            self.locationManager.startUpdatingLocation()
            
            
            
            // instead of this, you want to show your map screen here
            view.backgroundColor = .gray;
            
            // Do any additional setup after loading the view.
            
            
        }
        
        func setupLocationManager() {
            locationManager.delegate = self as? CLLocationManagerDelegate
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
        }
        
        func centerViewOnUserLocation() {
            if let location = locationManager.location?.coordinate {
                let region = MKCoordinateRegion.init(center: location, latitudinalMeters: regionInMeters, longitudinalMeters: regionInMeters)
                myMapView.setRegion(region, animated: true)
            }
        }
        
        func checkLocationServices() {
            if CLLocationManager.locationServicesEnabled() {
                setupLocationManager()
                checkLocationAuthorization()
            } else {
                //show alert for letting the user know they have to turn this on.
            }
        }
        
        func checkLocationAuthorization() {
            switch CLLocationManager.authorizationStatus() {
            case .authorizedWhenInUse:
                //  myMapView.showsUserLocation = true
                centerViewOnUserLocation()
                //14:30 on the video
                break
            case .denied:
                // Show alert instructing them how to turn on permissions
                break
            case .notDetermined:
                locationManager.requestWhenInUseAuthorization()
                break
            case .restricted:
                //Show an alert letting them know what's up
                break
            case .authorizedAlways:
                break
            }
            
            /*
             // MARK: - Navigation
             
             // In a storyboard-based application, you will often want to do a little preparation before navigation
             override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
             // Get the new view controller using segue.destination.
             // Pass the selected object to the new view controller.
             }
             */
            
        }
        
        
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            //we'll be back
        }
        
        
        func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
            //we'll be back
        }
        
        func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
            _ = MKCoordinateRegion(center: userLocation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
            // self.mapView.setRegion(region, animated: true)
            
        }
        
}
