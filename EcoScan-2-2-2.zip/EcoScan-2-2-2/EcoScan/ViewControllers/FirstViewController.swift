//
//  TreeTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class TreeTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // instead of this, you want to show your tree screen here
        view.backgroundColor = .white;
        
        
        
        // Do any additional setup after loading the view.
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    array = [ index0, index1, index2,index3, index4, index5]
    items = [ computer, aluminum, plastic, paper, glass, wood]
    points = [ 45,15,12,9,6,3]
    leaves = [ 3,2,1,1,1,1]

    func drawTree() {
        // let userPoints = points -> where is this point value & where are you getting it from?
        
        let userPoints = 3; // this is just for testing purposes
        
        if (userPoints <= 3) {
            var image: UIImage = UIImage(named: "tree.3.26")!
            var imageView = UIImageView(image: image)
            self.view.addSubview(imageView)
        }
        else if (userPoints <= 6) {
            var image: UIImage = UIImage(named: "tree.25")!
            var imageView = UIImageView(image: image)
            self.view.addSubview(imageView)
            
        else if (userpoints <= )
        }

    }
    
}
