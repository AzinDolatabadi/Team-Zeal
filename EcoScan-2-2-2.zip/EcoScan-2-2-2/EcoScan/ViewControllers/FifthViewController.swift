//
//  RewardTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class SearchTabBar: UITabBarController {
    @IBAction func cardboard(_ sender: UIButton) {
    }
    
    @IBAction func plastics(_ sender: UIButton) {
        func plasticBag(_ sender: UIButton) {}
        func plasticBottle(_ sender: UIButton) {}
        func plasticCap(_ sender: UIButton) {}
        func plasticContainer(_ sender: UIButton) {}
        func plasticCup(_ sender: UIButton) {}
        func plasticCutlery(_ sender: UIButton) {}
        func plasticHanger(_ sender: UIButton) {}
        func plasticPot(_ sender: UIButton) {}
        func rollOnDeodorant(_ sender: UIButton) {}
        func tubeOfToothpaste(_ sender: UIButton) {}
        func yogurtCup(_ sender: UIButton) {}
    }
    
    @IBAction func glass(_ sender: UIButton) {
    }
    
    @IBAction func aluminum(_ sender: UIButton) {
    }
    
    @IBAction func organic(_ sender: UIButton) {
    }
    
    
    @IBAction func paper(_ sender: UIButton) {
    }
    
    @IBAction func batteries(_ sender: UIButton) {
    }
    
    @IBAction func special(_ sender: UIButton) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // instead of this, you want to show your search screen here
        view.backgroundColor = .blue;
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
