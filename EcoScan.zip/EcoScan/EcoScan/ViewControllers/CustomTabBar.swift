//
//  CustomTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class CustomTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let firstVC = FirstViewController()
        let secondVC = SecondViewController()
        let thirdVC = ThirdViewController()
        let fourthVC = FourthViewController()
        let fifthVC = FifthViewController()
        
        firstVC.tabBarItem.title = "Tree"
        secondVC.tabBarItem.title = "Location"
        thirdVC.tabBarItem.title = "Home"
        fourthVC.tabBarItem.title = "Scan"
        fifthVC.tabBarItem.title = "Search"
        
        firstVC.tabBarItem.image = UIImage(named:"tree")
        secondVC.tabBarItem.image = UIImage(named:"location")
         thirdVC.tabBarItem.image = UIImage(named:"leaf")
         fourthVC.tabBarItem.image = UIImage(named:"barcode")
        fifthVC.tabBarItem.image = UIImage(named:"search")
        
        viewControllers = [firstVC, secondVC, thirdVC, fourthVC, fifthVC]
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
