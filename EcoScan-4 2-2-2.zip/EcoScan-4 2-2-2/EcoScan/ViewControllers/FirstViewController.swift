//
//  TreeTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

extension String {
    func toImage() -> UIImage? {
        if let data = Data(base64Encoded: self, options: .ignoreUnknownCharacters){
            return UIImage(data: data)
        }
        return nil
    }
}

class TreeTabBar: UITabBarController {
    
    @IBOutlet weak var treeImage: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        drawTree()

        // instead of this, you want to show your tree screen here
        view.backgroundColor = .white;
        
        // Do any additional setup after loading the view.
    }
    
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //let indexArray = [ index0, index1, index2,index3, index4, index5]
    let items = [ "computer", "aluminum", "plastic", "paper", "glass", "wood"]
    let points = [ 45,15,12,9,6,3]
    let leaves = [ 15,5,4,3,2,1]

    func drawTree() {
        // let userPoints = points -> where is this point value & where are you getting it from?
        
        let userPoints = 24;
        // this is just for testing purposes
        
        var imageName : String!
        
            
        switch userPoints{
        case 3:
            imageName = "tree.3.26.png"
        case 6:
            imageName = "tree.3.25.png"
        case 9:
            imageName = "tree.3.24.png"
        case 12:
            imageName = "tree.3.23.png"
        case 15:
            imageName = "tree.3.22.png"
        case 18:
            imageName = "tree.3.21.png"
        case 21:
            imageName = "tree.3.20.png"
        case 24:
            imageName = "tree.3.19.png"
        case 27:
            imageName = "tree.3.18.png"
        case 30:
            imageName = "tree.3.17.png"
        case 33:
            imageName = "tree.3.16.png"
        case 36:
            imageName = "tree.3.15.png"
        case 39:
            imageName = "tree.3.14.png"
        case 42:
            imageName = "tree.3.13.png"
        case 45:
            imageName = "tree.3.12.png"
        case 48:
            imageName = "tree.3.11.png"
        case 51:
            imageName = "tree.3.10.png"
        case 54:
            imageName = "tree.3.8.png"
        case 57:
            imageName = "tree.3.7.png"
        case 60:
            imageName = "tree.3.6.png"
        case 63:
            imageName = "tree.3.5.png"
        case 66:
            imageName = "tree.3.4.png"
        case 69:
            imageName = "tree.3.3.png"
        case 72:
            imageName = "tree.3.2.png"
        case 75:
            imageName = "tree.3.1.png"
        case 78:
            imageName = "tree.3.png"
            
            
        // continue this structure for all images
        default:
            break
        }
        
        self.treeImage.image = UIButton(named: imageName)
    }


}
