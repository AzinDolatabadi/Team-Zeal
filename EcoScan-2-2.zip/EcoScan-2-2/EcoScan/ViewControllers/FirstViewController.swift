//
//  TreeTabBar.swift
//  EcoScan
//
//  Created by Tech Team on 2019-03-20.
//  Copyright © 2019 Tech Team. All rights reserved.
//

import UIKit

class TreeTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // instead of this, you want to show your tree screen here
        view.backgroundColor = .white;
        
        
        
        // Do any additional setup after loading the view.
    }
    
    /*
     
    if userPoints <= 3 #imageLiteral(resourceName: "tree.3.25.jpg")
    if userPoints <= 6 #imageLiteral(resourceName: "tree.3.24.jpg")
    if userPoints <= 9
    if userPoints <= 12
    if userPoints <= 
    
*/
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    if userPoints <= 3  #imageLiteral (resourceName: "tree.3.25.jpg")
    if userPoints <= 6  #imageLiteral(resourceName: "tree.3.24")
    if userPoints <= 9  #imageLiteral(resourceName: "tree.3.23.jpg")
    if userPoints <= 12 #imageLiteral(resourceName: "tree.3.22.jpg")
    if userPoints <= 15 #imageLiteral(resourceName: "tree.3.21.jpg")
    if userPoints <= 18 #imageLiteral(resourceName: "tree.3.20.jpg")
    if userPoints <= 21 #imageLiteral(resourceName: "tree.3.19.jpg")
    if userPoints <= 24 #imageLiteral(resourceName: "tree.3.18.jpg")
    if userPoints <= 27 #imageLiteral(resourceName: "tree.3.17.jpg")
    if userPoints <= 30 #imageLiteral(resourceName: "tree.3.16.jpg")
    if userPoints <= 33 #imageLiteral(resourceName: "tree.3.15.jpg")
    if userPonits <= 36 #imageLiteral(resourceName: "tree.3.14.jpg")
    if userPoints <= 39 #imageLiteral(resourceName: "tree.3.13.jpg")
    if userPoints <= 42 #imageLiteral(resourceName: "tree.3.12.jpg")
    if userPoints <= 45 #imageLiteral(resourceName: "tree.3.11.jpg")
    if userPoints <= 48 #imageLiteral(resourceName: "tree.3.10.jpg")
    if userPoints <= 51 #imageLiteral(resourceName: "tree.3.8.jpg")
    if userPoints <= 54 #imageLiteral(resourceName: "tree.3.7.jpg")
    if userPoints <= 57 #imageLiteral(resourceName: "tree.3.6.jpg")
    if userPoints <= 60 #imageLiteral(resourceName: "tree.3.5.jpg")
    if userPoints <= 63 #imageLiteral(resourceName: "tree.3.4.jpg")
    if userPoints <= 66 #imageLiteral(resourceName: "tree.3.3.jpg")
    if userPoints <= 69 #imageLiteral(resourceName: "tree.3.2.jpg")
    if userPoints <= 72 #imageLiteral(resourceName: "tree.3.1.jpg")
    if userPoints <= 75 #imageLiteral(resourceName: "tree.3.jpg")

    
}
